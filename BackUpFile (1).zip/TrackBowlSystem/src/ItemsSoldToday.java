
import java.sql.PreparedStatement;
import java.awt.HeadlessException;
import javax.swing.JOptionPane;
//import java.lang.String;
import java.sql.Statement;
import java.sql.Connection;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;
import javax.swing.table.DefaultTableModel;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
/**
 *
 * @author User
 */
public final class ItemsSoldToday extends javax.swing.JFrame {

    private Connection con = null;
    private Statement st = null;
    private PreparedStatement pst = null;
    private ResultSet rs = null;

    private static final String DbName = "trackbowl";
    private static final String DbDriver = "com.mysql.cj.jdbc.Driver";
    private static final String DbUrl = "jdbc:mysql://localhost:3306/" + DbName;
    private static final String DbUsername = "root";
    private static final String DbPassword = "";
    private static final Logger LOGGER = Logger.getLogger(ItemsSoldToday.class.getName());

    static String accType;
    static String userLabel;
    //static int staffid = 012345;
    static double sales;
    static String date;
    static String staffid;

    public ItemsSoldToday(String userLabel, String staffid) {
        super(userLabel);
        this.staffid = staffid;
        initComponents();
        connectToDatabase();
        loadSoldItems();
        userShow.setText(userLabel);
        calculatePrice();
        showCurrentDate();
        currentSales.setEditable(false);
    }

    private void connectToDatabase() {
        try {
            Class.forName(DbDriver);
            con = DriverManager.getConnection(DbUrl, DbUsername, DbPassword);
            st = con.createStatement();
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    private void loadSoldItems() {
        ResultSet rs = null;
        try {
            DefaultTableModel model = (DefaultTableModel) itemSoldTable.getModel();
            model.setRowCount(0);
            rs = st.executeQuery("SELECT * FROM itemsoldtable");
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getString("item_code"),
                    rs.getString("item_name"),
                    rs.getInt("quantity"),
                    rs.getDouble("total_price"),
                    rs.getString("Mode"),
                    rs.getString("staff_id")
                });
            }
        } catch (SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
        } finally {
            try {
                if (rs != null) {
                    rs.close();
                }
            } catch (SQLException ex) {
                Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    void calculatePrice() {
        int sum = 0;
        String priceStr;
        double price;

        for (int i = 0; i < itemSoldTable.getRowCount(); i++) {
            priceStr = itemSoldTable.getValueAt(i, 3).toString();
            price = Double.parseDouble(priceStr);
            sum = (int) (sum + price);
        }

        currentSales.setText("₱" + sum);
        setTotalSales(sum);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        jPanel3 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        itemSoldTable = new javax.swing.JTable();
        jPanel2 = new javax.swing.JPanel();
        jLabel3 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        currentSales = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        closeShopButton = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        currentDateField = new javax.swing.JTextField();
        jLabel6 = new javax.swing.JLabel();
        userShow = new javax.swing.JLabel();
        refundButton = new javax.swing.JButton();
        exit = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        jLabel8 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("Today's Sales");
        setResizable(false);

        jPanel1.setBackground(new java.awt.Color(204, 0, 0));
        jPanel1.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));

        itemSoldTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {
                "Item Code", "Item Name", "Quantity", "Total Price (₱)", "Mode", "Staff ID"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        itemSoldTable.setSelectionMode(javax.swing.ListSelectionModel.SINGLE_SELECTION);
        itemSoldTable.getTableHeader().setReorderingAllowed(false);
        jScrollPane1.setViewportView(itemSoldTable);
        if (itemSoldTable.getColumnModel().getColumnCount() > 0) {
            itemSoldTable.getColumnModel().getColumn(0).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(1).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(2).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(3).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(4).setResizable(false);
            itemSoldTable.getColumnModel().getColumn(5).setResizable(false);
        }

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jScrollPane1, javax.swing.GroupLayout.DEFAULT_SIZE, 550, Short.MAX_VALUE)
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 548, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 10, 550, 550));

        jPanel2.setBackground(new java.awt.Color(255, 255, 255));
        jPanel2.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel3.setIcon(new javax.swing.ImageIcon(getClass().getResource("/trackbowlPics/logo1 (1).png"))); // NOI18N
        jPanel2.add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 6, -1, -1));

        jLabel2.setFont(new java.awt.Font("Bookman Old Style", 1, 18)); // NOI18N
        jLabel2.setText("Items Sold Today");
        jPanel2.add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 167, -1, -1));

        jPanel7.setBackground(new java.awt.Color(204, 0, 0));

        currentSales.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentSales, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentSales, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 240, -1, -1));

        jLabel5.setBackground(new java.awt.Color(204, 0, 0));
        jLabel5.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(204, 0, 0));
        jLabel5.setText("Current Sales:");
        jPanel2.add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 217, 150, -1));

        closeShopButton.setBackground(new java.awt.Color(204, 0, 0));
        closeShopButton.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        closeShopButton.setForeground(new java.awt.Color(255, 255, 255));
        closeShopButton.setText("CLOSE SHOP");
        closeShopButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                closeShopButtonActionPerformed(evt);
            }
        });
        jPanel2.add(closeShopButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 390, 150, -1));

        jPanel8.setBackground(new java.awt.Color(204, 0, 0));

        currentDateField.setFont(new java.awt.Font("Segoe UI Variable", 1, 14)); // NOI18N

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.DEFAULT_SIZE, 138, Short.MAX_VALUE)
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(currentDateField, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel2.add(jPanel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 310, -1, -1));

        jLabel6.setBackground(new java.awt.Color(204, 0, 0));
        jLabel6.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(204, 0, 0));
        jLabel6.setText("Current Date:");
        jPanel2.add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 285, 150, -1));

        userShow.setFont(new java.awt.Font("Segoe UI Variable", 1, 12)); // NOI18N
        userShow.setForeground(new java.awt.Color(255, 255, 255));
        userShow.setText("jLabel1");
        jPanel2.add(userShow, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 190, 60, -1));

        refundButton.setBackground(new java.awt.Color(255, 153, 51));
        refundButton.setFont(new java.awt.Font("Sitka Text", 1, 14)); // NOI18N
        refundButton.setForeground(new java.awt.Color(255, 255, 255));
        refundButton.setText("REFUND ITEM");
        refundButton.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                refundButtonActionPerformed(evt);
            }
        });
        jPanel2.add(refundButton, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 450, 150, -1));

        exit.setFont(new java.awt.Font("Segoe UI Variable", 1, 18)); // NOI18N
        exit.setForeground(new java.awt.Color(153, 0, 0));
        exit.setText("Back >>");
        exit.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exitMouseClicked(evt);
            }
        });
        jPanel2.add(exit, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 520, -1, 16));

        jLabel4.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel4.setText("Refund an Item Sold Today");
        jPanel2.add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 430, 150, 20));

        jLabel7.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel7.setText("History when Current Sales is 0!");
        jPanel2.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 370, 150, 20));

        jLabel8.setFont(new java.awt.Font("Segoe UI", 0, 10)); // NOI18N
        jLabel8.setText("*Record will not reflect on Sales");
        jPanel2.add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(10, 360, -1, -1));

        jPanel1.add(jPanel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(570, 10, 170, 550));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 750, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, 567, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents


    private void closeShopButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_closeShopButtonActionPerformed
        // TODO add your handling code here:
        int rowCount = itemSoldTable.getRowCount();

        if (rowCount == 0) {
            JOptionPane.showMessageDialog(null, "You cannot close shop when your total sales is " + currentSales.getText(), "Close Shop Unnecessary", JOptionPane.INFORMATION_MESSAGE);
            
        } else {
            int confirm = JOptionPane.showConfirmDialog(null, "Are you sure to close shop?\n\n>All rows will be deleted \n>Total Sales will be added to Sales History\n>Only the Admin can view the Sales History after closing shop", "Close Shop Confirmation", JOptionPane.YES_NO_OPTION);

            if (confirm == JOptionPane.YES_OPTION) {
                addToSales();

                try {
                    String sql = "DELETE FROM itemsoldtable";
                    pst = con.prepareStatement(sql);
                    pst.executeUpdate();

                    currentSales.setText("");
                } catch (SQLException | HeadlessException ex) {
                    JOptionPane.showMessageDialog(null, ex);
                } finally {
                    try {
                        if (pst != null) {
                            pst.close();
                        }
                    } catch (SQLException ex) {
                        Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
                    }
                    closeDatabaseConnection();
                }

                JOptionPane.showMessageDialog(null, "You Have Successfully Closed Shop!\nToday's data have been transferred to Sales History!\nTotal Sales today: " + currentSales.getText(), "Shop Closed", JOptionPane.INFORMATION_MESSAGE);

            }

            loadSoldItems();
        }
    }//GEN-LAST:event_closeShopButtonActionPerformed

    private void refundButtonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_refundButtonActionPerformed
        int selectedRow = itemSoldTable.getSelectedRow();
        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(null, "Please select a transaction to refund", "No item selected", JOptionPane.INFORMATION_MESSAGE);
            return;
        }

        String code = itemSoldTable.getValueAt(selectedRow, 0).toString();
        String name = itemSoldTable.getValueAt(selectedRow, 1).toString();
        int quantity = Integer.parseInt(itemSoldTable.getValueAt(selectedRow, 2).toString());
        String mode = itemSoldTable.getValueAt(selectedRow, 4).toString();
        String staff = itemSoldTable.getValueAt(selectedRow, 5).toString();
        Double totalPrice = Double.valueOf(itemSoldTable.getValueAt(selectedRow, 3).toString());

        int response = JOptionPane.showConfirmDialog(null, "Are you sure you want to proceed with the refund?\n\nItem Name: " + name + "\nQuantity Sold: " + quantity + "\nTotal Price: ₱" + totalPrice, "Refund Confirmation", JOptionPane.YES_NO_OPTION);

        if (response == JOptionPane.YES_OPTION) {
            try {
                con.setAutoCommit(false); // Start transaction

                // Delete from itemsoldtable
                String sql = "DELETE FROM itemsoldtable WHERE item_code = ? AND quantity = ? AND Mode = ?";
                try (PreparedStatement pst = con.prepareStatement(sql)) {
                    pst.setString(1, code);
                    pst.setInt(2, quantity);
                    pst.setString(3, mode);
                    pst.executeUpdate();
                    System.out.println("Deleted from itemsoldtable");
                }

                // Remove row from JTable
                DefaultTableModel model = (DefaultTableModel) itemSoldTable.getModel();
                model.removeRow(selectedRow);

                // Update inventory_items
                String sql1 = "UPDATE inventory_items SET `Stocks Left` = `Stocks Left` + ? WHERE `id` = ?";
                try (PreparedStatement pst = con.prepareStatement(sql1)) {
                    pst.setInt(1, quantity);
                    pst.setString(2, code);
                    pst.executeUpdate();
                    System.out.println("Updated Inventory");
                }

                // Delete from all_items_sold
                AllItemsSold all = new AllItemsSold();
                all.refund(name, quantity, totalPrice, mode, staff, date);
                System.out.println("Deleted from all items sold");

              
                con.commit(); // Commit transaction
            } catch (SQLException ex) {
                try {
                    con.rollback(); // Rollback transaction in case of error
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                JOptionPane.showMessageDialog(null, "Error: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            } finally {
                try {
                    con.setAutoCommit(true); // Restore default auto-commit behavior
                } catch (SQLException e) {
                    e.printStackTrace();
                }
            }
            calculatePrice();
        }

    }//GEN-LAST:event_refundButtonActionPerformed

    private void exitMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exitMouseClicked
        // TODO add your handling code here:
        dispose();
        if (userShow.getText().equals("Staff")) {
            Display sales = new Display("Staff", "user", staffid);
            sales.show();
        } else if (userShow.getText().equals("Admin")) {
            Display sales = new Display("Admin", "user", "Admin");
            sales.show();
        }
    }//GEN-LAST:event_exitMouseClicked

    /**
     * *
     */
    private void closeDatabaseConnection() {
        try {
            if (con != null) {
                con.close();
            }
        } catch (SQLException ex) {
            Logger.getLogger(ItemsSoldToday.class.getName()).log(Level.SEVERE, null, ex);
        }
    }

    public void showCurrentDate() {
        TimeZone.setDefault(TimeZone.getTimeZone("Asia/Manila"));

        // Get the current date and format it
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String currentDate = dateFormat.format(new Date());

        // Set the current date as the text of the JTextField
        currentDateField.setText(currentDate);
        currentDateField.setEditable(false);
        date = currentDate;

    }

    void setTotalSales(double sum) {
        sales = sum;
    }

    public double getSales() {
        return sales;
    }

    private void addToSales() {

        try {
            String sql = "INSERT INTO salestoday"
                    + "(`Date`,`Sales`)"
                    + "VALUES (?,?)";

            con = DriverManager.getConnection("jdbc:mysql://localhost/trackbowl", "root", "");
            pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, currentDateField.getText());
            pst.setDouble(2, sales);
            pst.executeUpdate();

        } catch (HeadlessException | SQLException ex) {
            JOptionPane.showMessageDialog(null, ex);
        }
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ItemsSoldToday.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ItemsSoldToday(accType, staffid).setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton closeShopButton;
    private javax.swing.JTextField currentDateField;
    private javax.swing.JTextField currentSales;
    private javax.swing.JLabel exit;
    private javax.swing.JTable itemSoldTable;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JButton refundButton;
    private javax.swing.JLabel userShow;
    // End of variables declaration//GEN-END:variables
}
